import React from 'react'

function TodoList(props) {

    return (
        props.todo.map(todo => {
            return (
                <div className='mx-5 mt-4 w-50'>
                    <ul className="list-group ">
                        <li className="list-group-item">{todo.title}</li>
                        <li className="list-group-item">{todo.desc}</li>
                    </ul>
                </div>
            )
        })
    )
}

export default TodoList