import React, { useState } from 'react'

const Form = (props) => {

    return (
        <div className=" mx-5">
            <form className='w-50 mt-3' onSubmit={(prev) => props.handleSubmit(prev)}>
                <div id="emailHelp" className="form-text mb-3 mt-3">Keep forgetting important tasks? Look No Further!</div>
                <div className="mb-3">
                    <label htmlFor="title" className="form-label">Title</label>
                    <input type="text" className="form-control" onChange={(obj) => props.handleTitle(obj)} id="title" placeholder='Name task' />
                </div>
                <div className="mb-3">
                    <label htmlFor="description" className="form-label">Description</label>
                    <input type="text" className="form-control" onChange={(obj2) => props.handleDesc(obj2)} id="description" placeholder='Describe task' />
                </div>
                <button type="submit" className="btn btn-primary px-5 pl-5 w-100" onClick={props.addTask} >Add Task</button>
            </form>
        </div>
    )
}


export default Form