import { useState } from 'react';

function Header() {
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                <a className="navbar-brand  mx-3" href="#" >MY TODOLIST</a>
                <div className="collapse navbar-collapse" id="navbarText">
                    <span className="nav navbar-text navbar-right mx-5 px-5 ">
                        Total Tasks: { }
                    </span>

                </div>
            </nav>

        </div>
    )
}


export default Header