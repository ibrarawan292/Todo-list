import { useState } from 'react';
import './App.css';
import Header from './components/Header'
import Form from "./components/Form"
import TodoList from "./components/TodoList"
import Footer from "./components/Footer"

function App() {

  const [title, setTitle] = useState("")
  const [desc, setDesc] = useState("")

  const handleTitle = (obj) => setTitle(obj.target.value)
  const handleDesc = (obj2) => setDesc(obj2.target.value)
  const handleSubmit = (prev) => prev.preventDefault()

  let [todo, setTodo] = useState([
    {
      title: "This is a new task",
      desc: "This is some description"
    },
    {
      title: "This is another new task",
      desc: "This is another description"
    }
  ])

  const addTask = () => {
    const newTsk =
    {
      title: title,
      desc: desc
    }

    setTodo([...todo, newTsk])
    console.log([...todo, newTsk])
  }

  return (
    <div>
      <Header />

      <Form
        title={title}
        desc={desc}
        todo={todo}
        handleTitle={handleTitle}
        handleDesc={handleDesc}
        handleSubmit={handleSubmit}
        setTitle={setTitle}
        setDesc={setDesc}
        setTodo={setTodo}
        addTask={addTask}
      />

      <TodoList title={title}
        desc={desc}
        todo={todo}
      />




    </div>
  )
}

export default App;
